#pragma once

// Cautions: Only for debug usage, the code using the following marcos is not portable

#define BLUE(str) std::string("\033[1;34m") + str + std::string("\033[0m")
#define GREEN(str) std::string("\033[1;32m") + str + std::string("\033[0m")
#define RED(str) std::string("\033[1;31m") + str + std::string("\033[0m")
#define YELLOW(str) std::string("\033[1;33m") + str + std::string("\033[0m")
#define CLAY(str) std::string("\033[1;36m") + str + std::string("\033[0m")
#define PURPLE(str) std::string("\033[1;35m") + str + std::string("\033[0m")
#define WHITE(str) std::string("\033[1;37m") + str + std::string("\033[0m")
#define BLACK(str) std::string("\033[1;30m") + str + std::string("\033[0m")
