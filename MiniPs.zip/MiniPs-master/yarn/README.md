This is a gradle project, you must install gradle to constuct the project and export jar package.
To install gradle, you can refer to https://gradle.org

run
```
  gradle build
```
to export a jar package (in ./build/libs) for running.
